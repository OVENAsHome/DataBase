from datetime import datetime
from sqlalchemy import func
from flask import Flask, render_template, request, redirect, url_for
from models import db, Candidate, Vacancy, HR_Manager, HeadOfProj, Role, Project

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:mereecazac@localhost:3306/me2'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

@app.route('/')
def home():
    return render_template('home.html')

# --- Кандидаты ---
@app.route('/candidates')
def index():
    candidates = Candidate.query.all()
    return render_template('index.html', candidates=candidates)

@app.route('/add', methods=['GET', 'POST'])
def add_candidate():
    if request.method == 'POST':
        fullname = request.form['fullname']
        summary = request.form['summary']
        docs = request.form['docs']
        vacancy_id = request.form['vacancy_id']
        hr_id = request.form['hr_id']

        new_candidate = Candidate(
            FullName=fullname,
            Summary=summary,
            Docs=docs,
            vacancy_idVacancy=vacancy_id,
            hr_manager_idHR_Manager=hr_id
        )
        db.session.add(new_candidate)
        db.session.commit()
        return redirect(url_for('index'))

    return render_template('add.html')

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_candidate(id):
    candidate = Candidate.query.get_or_404(id)
    if request.method == 'POST':
        candidate.FullName = request.form['fullname']
        candidate.Summary = request.form['summary']
        candidate.Docs = request.form['docs']
        candidate.vacancy_idVacancy = request.form['vacancy_id']
        candidate.hr_manager_idHR_Manager = request.form['hr_id']
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('edit.html', candidate=candidate)

@app.route('/delete/<int:id>')
def delete_candidate(id):
    candidate = Candidate.query.get_or_404(id)
    db.session.delete(candidate)
    db.session.commit()
    return redirect(url_for('index'))

# --- Главы проектов ---
@app.route('/heads')
def heads():
    heads = HeadOfProj.query.all()
    return render_template('heads.html', heads=heads)

@app.route('/add_head', methods=['GET', 'POST'])
def add_head():
    if request.method == 'POST':
        fullname = request.form['fullname']
        decision = request.form['decision']
        new_head = HeadOfProj(FullName=fullname, FinalDecision=decision)
        db.session.add(new_head)
        db.session.commit()
        return redirect(url_for('heads'))

    return render_template('add_head.html')

@app.route('/heads/edit/<int:id>', methods=['GET', 'POST'])
def edit_head(id):
    head = HeadOfProj.query.get_or_404(id)
    if request.method == 'POST':
        head.FullName = request.form['fullname']
        head.FinalDecision = request.form['decision']
        db.session.commit()
        return redirect(url_for('heads'))
    return render_template('edit_head.html', head=head)

@app.route('/heads/delete/<int:id>')
def delete_head(id):
    head = HeadOfProj.query.get_or_404(id)
    db.session.delete(head)
    db.session.commit()
    return redirect(url_for('heads'))

@app.route('/average_salary_by_head', methods=['GET', 'POST'])
def average_salary_by_head():
    if request.method == 'POST':
        fullname = request.form['fullname']
        avg_salary = db.session.query(func.avg(Role.Salary))\
            .join(HeadOfProj)\
            .filter(HeadOfProj.FullName == fullname)\
            .scalar()
        return render_template('avg_salary_result.html', fullname=fullname, avg_salary=avg_salary)
    return render_template('avg_salary_input.html')

@app.route('/projects_summary', methods=['POST'])
def projects_summary():
    date_str = request.form.get('date_end')
    try:
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
    except ValueError:
        return "Неверный формат даты", 400

    results = db.session.query(
        Project.Name.label('project_name'),
        HeadOfProj.FullName.label('head_name'),
        func.count(Role.idRole).label('role_count')
    ).join(HeadOfProj, Project.head_of_proj_idHead_of_proj == HeadOfProj.idHead_of_proj) \
     .join(Role, Role.head_of_proj_idHead_of_proj == HeadOfProj.idHead_of_proj) \
     .filter(Project.EndDate == date_obj) \
     .group_by(Project.idProject, Project.Name, HeadOfProj.FullName) \
     .all()

    return render_template('projects_summary.html', results=results, date=date_str)

if __name__ == '__main__':
    with app.app_context():
        db.create_all() 
    app.run(debug=True)