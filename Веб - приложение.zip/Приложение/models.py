from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Vacancy(db.Model):
    __tablename__ = 'vacancy'
    idVacancy = db.Column(db.Integer, primary_key=True)
    EmploymentType = db.Column(db.String(100))
    # другие поля можно не указывать, если не нужны

class HR_Manager(db.Model):
    __tablename__ = 'hr_manager'
    idHR_Manager = db.Column(db.Integer, primary_key=True)
    ContactOfCandidates = db.Column(db.String(255))
    # другие поля можно не указывать

class Candidate(db.Model):
    __tablename__ = 'candidate'
    idCandidate = db.Column(db.Integer, primary_key=True)
    FullName = db.Column(db.String(255), nullable=False)
    Summary = db.Column(db.String(255), nullable=False)
    Docs = db.Column(db.String(255), nullable=False)
    vacancy_idVacancy = db.Column(db.Integer, db.ForeignKey('vacancy.idVacancy'), nullable=False)
    hr_manager_idHR_Manager = db.Column(db.Integer, db.ForeignKey('hr_manager.idHR_Manager'), nullable=False)

    vacancy_idVacancy = db.Column(db.Integer, db.ForeignKey('vacancy.idVacancy'))
    hr_manager_idHR_Manager = db.Column(db.Integer, db.ForeignKey('hr_manager.idHR_Manager'))

    vacancy = db.relationship('Vacancy', backref='candidates')
    hr_manager = db.relationship('HR_Manager', backref='candidates')

class HeadOfProj(db.Model):
    __tablename__ = 'head_of_proj'
    idHead_of_proj = db.Column(db.Integer, primary_key=True)
    FullName = db.Column(db.String(100), nullable=False)
    FinalDecision = db.Column(db.String(50))
    projects = db.relationship('Project', backref='head_of_proj', lazy=True)


class Project(db.Model):
    __tablename__ = 'project'
    idProject = db.Column(db.Integer, primary_key=True)
    Name = db.Column(db.String(100), nullable=False)
    EndDate = db.Column(db.Date)
    head_of_proj_idHead_of_proj = db.Column(db.Integer, db.ForeignKey('head_of_proj.idHead_of_proj'))



class Role(db.Model):
    __tablename__ = 'role'

    idRole = db.Column(db.Integer, primary_key=True)
    Salary = db.Column(db.Float)

    head_of_proj_idHead_of_proj = db.Column(
        db.Integer,
        db.ForeignKey('head_of_proj.idHead_of_proj')
    )

    head_of_proj = db.relationship('HeadOfProj', backref='roles')